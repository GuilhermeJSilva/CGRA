var rimOptions = { 'Vintage Rim': 0, 'New Rim': 1 };
var carOptions = { 'Light blue': 0, 'Forest Camo': 1 };