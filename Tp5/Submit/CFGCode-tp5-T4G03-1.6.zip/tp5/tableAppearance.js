class tableAppearance extends CGFappearance {

  this.setAmbient(0.545, 0.271, 0.075,1);
  this.setDiffuse(0.545, 0.271, 0.075,1);
  this.setSpecular(0.1,0.1,0.1,1);
  this.loadTexture("../resources/images/table.png");

}
